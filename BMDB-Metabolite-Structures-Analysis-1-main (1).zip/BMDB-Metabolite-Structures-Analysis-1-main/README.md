# BMDB-Metabolite-Structures-Analysis
This repo is part of an essay from "Introduction to R programming language" for CENTRO UNIVERSITÁRIO DE BRASÍLIA.

Here we analyse some of the main characteristics of any Metabolite and the coorrelation between them.

The code in Python contained here is a great example of data extraction and transformation.
